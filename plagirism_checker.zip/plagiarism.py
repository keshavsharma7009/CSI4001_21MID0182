import re
import requests
import fitz  # PyMuPDF
import docx
import nltk
from bs4 import BeautifulSoup
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from collections import Counter
from sentence_transformers import SentenceTransformer, util
import numpy as np
import textstat
import language_tool_python

# Download NLTK stopwords
nltk.download('stopwords')
from nltk.corpus import stopwords

# Load pre-trained BERT model
bert_model = SentenceTransformer("all-MiniLM-L6-v2")
model = SentenceTransformer('paraphrase-MiniLM-L6-v2')

from transformers import pipeline
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

def get_readability_score(text):
    score = textstat.flesch_reading_ease(text)
    levels = [(80, "Very Easy (5th Grade Level)"), (60, "Easy (8th Grade Level)"), 
              (50, "Moderate (High School Level)"), (30, "Difficult (College Level)"), 
              (0, "Very Difficult (Advanced Level)")]
    for threshold, level in levels:
        if score >= threshold:
            return f"{score:.2f} - {level}"
    return f"{score:.2f} - Unknown Level"

def check_grammar(text):
    tool = language_tool_python.LanguageTool('en-US')
    matches = tool.check(text)

    if not matches:
        return text, "No grammar issues found ✅"

    highlighted_text = text
    error_list = []

    for match in matches:
        error_text = match.context[match.offset: match.offset + match.errorLength]
        suggestion = match.replacements[0] if match.replacements else "No suggestion"
        highlighted_text = re.sub(re.escape(error_text), f'<span style="color: red;">{error_text}</span>', 
                                  highlighted_text, count=1)
        error_list.append(f"- {match.ruleIssueType.capitalize()}: {match.message} (Suggestion: <b>{suggestion}</b>)")

    return highlighted_text, "<br>".join(error_list)

def highlight_plagiarism(text1, text2):
    sentences1 = re.split(r'(?<=[.!?])\s+', text1)
    sentences2 = re.split(r'(?<=[.!?])\s+', text2)

    highlighted_text = ""
    for sent in sentences1:
        sent_embedding = model.encode(sent, convert_to_tensor=True)
        similarities = [util.pytorch_cos_sim(sent_embedding, model.encode(s, convert_to_tensor=True)).item() for s in sentences2]
        max_similarity = max(similarities) if similarities else 0
        color = "red" if max_similarity > 0.7 else "green"
        highlighted_text += f'<span style="color:{color}">{sent} </span>'

    return highlighted_text

def summarize_text(text, max_length=150, min_length=50):
    if len(text.split()) < min_length:
        return text
    summary = summarizer(text, max_length=max_length, min_length=min_length, do_sample=False)
    return summary[0]['summary_text']

def compute_similarity_bert(text1, text2):
    embeddings = bert_model.encode([text1, text2])
    similarity_score = cosine_similarity([embeddings[0]], [embeddings[1]])[0][0]
    return similarity_score * 100

def extract_text_from_file(file_path):
    text = ""
    if file_path.endswith(".txt"):
        with open(file_path, "r", encoding="utf-8") as f:
            text = f.read()
    elif file_path.endswith(".pdf"):
        doc = fitz.open(file_path)
        extracted_text = [preprocess_pdf_text(page.get_text("text")) for page in doc]
        text = "\n".join(extracted_text)
    elif file_path.endswith(".docx"):
        doc = docx.Document(file_path)
        extracted_text = [para.text for para in doc.paragraphs if para.text.strip()]
        text = "\n".join(extracted_text)
    return text if text else None

def preprocess_pdf_text(text):
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'Page\s+\d+|\d+\s+of\s+\d+', '', text)
    text = re.sub(r'[^\w\s.,;!?]', '', text)
    return text.strip()

def clean_text(text):
    text = re.sub(r'\W+', ' ', text.lower())
    words = text.split()
    words = [word for word in words if word not in stopwords.words('english')]
    return " ".join(words)

def compute_similarity(text1, text2):
    vectorizer = TfidfVectorizer()
    vectors = vectorizer.fit_transform([text1, text2])
    return cosine_similarity(vectors)[0][1] * 100

def unique_word_count(text):
    return len(set(text.split()))

def find_online_sources(text):
    search_url = "https://www.google.com/search?q=" + "+".join(text.split()[:10])
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(search_url, headers=headers)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        links = [a['href'] for a in soup.find_all('a', href=True) if "http" in a['href']]
        return links[:5]
    return []
