import sys
import os
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QLabel, QTextEdit, QPushButton, QFileDialog
)
from PyQt5.QtGui import QDragEnterEvent, QDropEvent
from PyQt5.QtCore import Qt
from plagiarism import (
    extract_text_from_file,
    compute_similarity_bert,
    summarize_text,
    highlight_plagiarism,
    get_readability_score,
    check_grammar,
)

class PlagiarismChecker(QMainWindow):
    def __init__(self):
        super().__init__()
        self.file1 = None
        self.file2 = None
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Plagiarism Detector")
        self.setGeometry(100, 100, 700, 600)
        
        # Drag & Drop Labels
        self.label1 = QLabel("Drag & drop Document 1 here or click to upload", self)
        self.label1.setGeometry(50, 30, 600, 60)
        self.label1.setAlignment(Qt.AlignCenter)
        self.label1.setStyleSheet("border: 2px dashed #aaa; padding: 10px; font-size: 14px;")
        
        self.label2 = QLabel("Drag & drop Document 2 here or click to upload", self)
        self.label2.setGeometry(50, 110, 600, 60)
        self.label2.setAlignment(Qt.AlignCenter)
        self.label2.setStyleSheet("border: 2px dashed #aaa; padding: 10px; font-size: 14px;")

        # Result Display Area
        self.resultArea = QTextEdit(self)
        self.resultArea.setGeometry(50, 200, 600, 250)
        self.resultArea.setReadOnly(True)

        # Upload Buttons
        self.uploadBtn1 = QPushButton("Upload Document 1", self)
        self.uploadBtn1.setGeometry(50, 470, 200, 40)
        self.uploadBtn1.clicked.connect(self.upload_file1)

        self.uploadBtn2 = QPushButton("Upload Document 2", self)
        self.uploadBtn2.setGeometry(270, 470, 200, 40)
        self.uploadBtn2.clicked.connect(self.upload_file2)

        # Plagiarism Check Button
        self.checkBtn = QPushButton("Check Plagiarism", self)
        self.checkBtn.setGeometry(50, 520, 200, 40)
        self.checkBtn.clicked.connect(self.check_plagiarism)

        # Exit Button
        self.exitBtn = QPushButton("Exit", self)
        self.exitBtn.setGeometry(270, 520, 200, 40)
        self.exitBtn.clicked.connect(self.close)

        # Enable Drag & Drop
        self.setAcceptDrops(True)
    
    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
    
    def dropEvent(self, event: QDropEvent):
        urls = event.mimeData().urls()
        if urls:
            file_path = urls[0].toLocalFile()
            if not self.file1:
                self.file1 = file_path
                self.label1.setText(f"File Selected: {os.path.basename(self.file1)}")
            else:
                self.file2 = file_path
                self.label2.setText(f"File Selected: {os.path.basename(self.file2)}")

    def upload_file1(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Select Document 1", "", "Documents (*.txt *.pdf *.docx)")
        if file_name:
            self.file1 = file_name
            self.label1.setText(f"File Selected: {os.path.basename(file_name)}")

    def upload_file2(self):
        file_name, _ = QFileDialog.getOpenFileName(self, "Select Document 2", "", "Documents (*.txt *.pdf *.docx)")
        if file_name:
            self.file2 = file_name
            self.label2.setText(f"File Selected: {os.path.basename(file_name)}")

    def check_plagiarism(self):
        if not self.file1 or not self.file2:
            self.resultArea.setText("Please upload both documents first.")
            return

        text1 = extract_text_from_file(self.file1)
        text2 = extract_text_from_file(self.file2)

        if not text1 or not text2:
            self.resultArea.setText("Error reading files. Ensure they are valid documents.")
            return

        similarity = compute_similarity_bert(text1, text2)
        summary = summarize_text(text1)
        highlighted_text = highlight_plagiarism(text1, text2)
        readability_score = get_readability_score(text1)
        highlighted_grammar_text, grammar_issues = check_grammar(text1)

        result_text = f"<b>Plagiarism Similarity:</b> {similarity:.2f}%<br><br>"
        result_text += f"<b>Summary:</b><br>{summary}<br><br>"
        result_text += f"<b>Plagiarism Report:</b><br>{highlighted_text}<br><br>"
        result_text += f"<b>Readability Score:</b> {readability_score}<br><br>"
        result_text += f"<b>Grammar Issues:</b><br>{grammar_issues}<br><br>"
        result_text += f"<b>Grammar Highlighted Text:</b><br>{highlighted_grammar_text}"

        self.resultArea.setHtml(result_text)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PlagiarismChecker()
    window.show()
    sys.exit(app.exec_())
